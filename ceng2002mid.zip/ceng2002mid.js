

// q2

function q2() {
  var a = 5; b = 7;
  var c = a+b>10 ? (a<b ? 10 : 20) : 30; // line 2
  var d = ("abc" || 7) && ("" || 7<3 || 0) && 3;
  console.log(c,d);
}

// q2()

// q4

function q4() {
  
  var people = [ {name:'ali', age:19},  {name:'oya', age:7}, {name:'izzet', age:25}, 
                 {name:'can', age:93},  {name:'zeynep', age:11} ]

  var result = people.reduce(function(tally, nextPerson, i){
    console.group()
    console.log("Processing " + (+i) + "th value(", nextPerson, ")...");
    console.log("Start values: tally= { x:"+ tally.x+ " y:" + tally.y+ " last: "+ tally.last + " }")
    if (nextPerson.age < 20) 
      tally.x++;
    else { 
      tally.y++;
      tally.last = nextPerson.name;
    }  
    console.log("End values: tally= { x:"+ tally.x+ " y:" + tally.y+ " last: "+ tally.last + " }")
    console.groupEnd()
    return tally;
  }, {x: 0, y:0} );
      
  console.log(result); // print contents of variable result
}
                             
q4() 
/*
Exception: SyntaxError: missing ) after argument list
@Scratchpad/1:8
*/                            
    
/* var fs = { 
  a: function (t1,t2) {
       if (t2.name.length != t1.name.length) return t2.name.length - t1.name.length;
       else if (t1.points != t2.points) return t2.points - t1.points;
       else return t1.played - t2.played;
     },
  b: function(t) {
    console.log(t.name + ": " + t.points + "-" + t.played);
  }
}
          
var g = function(n) {
  return function(t) {
    return t.played >= n;
  }
}

function compute(t) {
   t.points = 2*t.wins+t.draws;
   t.played=t.wins+t.draws+t.losses
}

var teams = [
  { name: "HataySpor", "wins": 3, "draws": 2, "losses": 1},
  { name: "HataySporrr", "wins": 2, "draws": 2, "losses": 2},
  { name: "Karabük", "wins": 7, "draws": 2, "losses": 1},
  { name: "Muğlaspor", "wins": 3, "draws": 2, "losses": 0},
  { name: "UlaGücü", "wins": 1, "draws": 3, "losses": 0},
  { name: "Kötekli", "wins": 1, "draws": 7, "losses": 0},
  { name: "Dalaman", "wins": 2, "draws": 0, "losses": 0}
]
teams.map(compute)
teams.filter(g(3)).sort(fs.a).forEach(fs.b)
*/



// q4

function f(obj, a, b, c, x, y) {
  obj.a++;
  a++;
  obj.b.push(30)
  b.push(30)
  b[0]++;
  y++;
  obj.c.x = "def"
  c.x = "def"
  x = "def"
}
var obj = { a:1, b:[10,20], c: {x:"abc"} }
var a = 1
var b = [10,20]
var c = {x:"abc"}
var x = "abc"
var y = b[0]
f(obj,a,b,c,x,y)
console.log(obj,a,b,c,x)
console.log(c == obj.c)


/* 
var x=1, y=2, z=3;
                                                       
function f() {
  var z = 9;
  x = 4;
  g(x,y)
  console.log("f2", x, y, z)
}
                                                       
function g(a,b) {
  var y = 6;
  z = 7
  function h(z) {
    console.log("h1", x, y, z);
    x++; y++; z++
    console.log("h2", x, y, z);
  }
  h(z);
  console.log("g2", x, y, z);
}
                                                                                                             //
console.log("global", x, y, z)
f()
console.log("global", x, y, z)
*/