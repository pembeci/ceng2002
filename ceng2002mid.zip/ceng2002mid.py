
def q2():
    a = 5
    b = 7
    c = (10 if a<b else 20) if a+b>10 else 30
    return c

def q5():
    a = [ 3, {'x':3, 'y':[10,20]}, [1,2,3]  ]
    # assignments
    b = a[:]
    c = b
    y = a[1]['y']
    y1 = y[1]
    y2 = a[1]['y'][:]
    # modifications
    a[2] = [1,2,3]
    y1 = 30
    y2.append(50)
    c[2].append(70)
    a[1]['x'] = 90
    b[0] = "xyz"
    test = y is y2
    for (k,v) in locals().items():
        print("{0} = {1}".format(k,v))
    #
# q5()


def f(a,inc):
  def g(b):
    nonlocal a  # we need this in python since we want to modify a
    a += inc    # inc is not modified so no need to declare it nonlocal
    return b*a
  return g

g = f(5,1)
print(g(7))
h = f(3,2)
print(h(7))
print(h(8))
print(h(7))
print(g(7))
